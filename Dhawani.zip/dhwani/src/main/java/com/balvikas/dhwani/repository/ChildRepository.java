package com.balvikas.dhwani.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.balvikas.dhwani.entity.Child;


public interface ChildRepository extends JpaRepository<Child,Integer> {

}
