package com.balvikas.dhwani;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DhwaniApplication {

	public static void main(String[] args) {
		SpringApplication.run(DhwaniApplication.class, args);
	}

}
