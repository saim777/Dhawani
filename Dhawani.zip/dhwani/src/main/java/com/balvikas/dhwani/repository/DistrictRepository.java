package com.balvikas.dhwani.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.balvikas.dhwani.entity.District;

public interface DistrictRepository extends JpaRepository<District,Integer> {

}
