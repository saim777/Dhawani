package com.balvikas.dhwani.dto;

public class ChildDto {
	public String ChildName;

	public ChildDto() {}
	public String getChildName() {
		return ChildName;
	}

	public void setChildName(String childName) {
		ChildName = childName;
	}
	
}
