package com.balvikas.dhwani.dto;


public class StateDto {
  
	public String StateName;

	public StateDto() {}
	public String getStateName() {
		return StateName;
	}

	public void setStateName(String stateName) {
		StateName = stateName;
	}


  
}
