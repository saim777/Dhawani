package com.balvikas.dhwani.dto;


public class DistrictDto {

	 public String stateName;
	 public String districtName;
	public String getStateName() {
		return stateName;
	}
	public void setStateName(String stateName) {
		this.stateName = stateName;
	}
	public String getDistrictName() {
		return districtName;
	}
	public void setDistrictName(String districtName) {
		this.districtName = districtName;
	}
	 
}
