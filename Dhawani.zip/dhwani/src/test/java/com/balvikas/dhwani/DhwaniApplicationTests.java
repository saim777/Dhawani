package com.balvikas.dhwani;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DhwaniApplicationTests {

	@Test
	void contextLoads() {
	}

}
